package med.voll.apiAlura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiAluraApplicationTests {

	@Test
	void contextLoads() {
	}

}
